// ===================================================
//  PASTE YOUR FREE GEMINI API KEY BELOW
//  Get it FREE from: https://aistudio.google.com
//  Click "Get API Key" -> "Create API Key" -> Copy
// ===================================================
const GEMINI_API_KEY = 'PASTE_YOUR_GEMINI_KEY_HERE';
// ===================================================

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

let lastQuery = '';
let savedTools = JSON.parse(localStorage.getItem('tf_saved') || '[]');

async function doSearch() {
  const query = document.getElementById('mainQuery').value.trim();
  if (!query) return;

  // Check if key is added
  if (!GEMINI_API_KEY || GEMINI_API_KEY === 'PASTE_YOUR_GEMINI_KEY_HERE') {
    document.getElementById('resultsSection').style.display = 'block';
    document.getElementById('resultsQuery').textContent = '"' + query + '"';
    document.getElementById('resultsCount').textContent = 'Key missing';
    document.getElementById('resultsGrid').innerHTML = `
      <div style="grid-column:1/-1;background:#1c1c27;border:1px solid rgba(252,92,125,0.4);border-radius:16px;padding:32px;text-align:center;">
        <div style="font-size:32px;margin-bottom:12px;">🔑</div>
        <div style="color:#fff;font-size:16px;font-weight:600;margin-bottom:10px;">Gemini API Key Not Added</div>
        <div style="color:#9996b0;font-size:14px;line-height:1.8;">
          1. Go to <strong style="color:#7c5cfc;">aistudio.google.com</strong><br/>
          2. Click <strong>Get API Key</strong> → <strong>Create API Key</strong><br/>
          3. Open <code style="color:#43e97b;">js/app.js</code> in Notepad<br/>
          4. Replace <code style="color:#fc5c7d;">PASTE_YOUR_GEMINI_KEY_HERE</code> with your key<br/>
          5. Save and re-upload to Netlify
        </div>
      </div>`;
    return;
  }

  lastQuery = query;
  showResultsSection();
  document.getElementById('resultsQuery').textContent = '"' + query + '"';
  document.getElementById('resultsCount').textContent = 'Searching…';
  document.getElementById('resultsGrid').innerHTML = buildSkeletons(4);
  document.getElementById('searchBtn').classList.add('loading');

  const prompt = `You are ToolFinder AI. The user described what they need: "${query}"

Find 4 to 6 best tools, apps, websites, or resources that match what the user needs.
Include AI tools, online tools, developer tools, student tools, movies, games — anything useful.

Return ONLY a valid JSON array. No markdown. No backticks. No explanation. Just the raw JSON array.

Each item in the array must have these exact fields:
{
  "name": "Tool name",
  "url": "https://actual-working-website.com",
  "pricing": "free",
  "category": "AI Tool",
  "description": "One sentence about what this tool does.",
  "whyMatch": "One sentence why this matches what the user needs.",
  "tags": ["tag1", "tag2"]
}

pricing must be exactly one of: free, freemium, paid
category must be exactly one of: AI Tool, Online Tool, Developer Tool, Student Tool, Entertainment, Productivity, Design, Business

Only suggest real tools with real working URLs.
For movies: set url to https://www.justwatch.com/in/search?q=MovieName and category to Entertainment.

Return ONLY the JSON array starting with [ and ending with ].`;

  try {
    const res = await fetch(`${GEMINI_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      })
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error?.message || 'API error ' + res.status);
    }

    const data = await res.json();
    let text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    text = text.replace(/```json|```/g, '').trim();

    // Extract JSON array from response
    const start = text.indexOf('[');
    const end = text.lastIndexOf(']');
    if (start === -1 || end === -1) throw new Error('Invalid response from AI');
    const tools = JSON.parse(text.slice(start, end + 1));

    renderResults(tools);

  } catch (e) {
    document.getElementById('resultsGrid').innerHTML = `
      <div style="grid-column:1/-1;background:#1c1c27;border:1px solid rgba(252,92,125,0.4);border-radius:16px;padding:32px;text-align:center;">
        <div style="font-size:32px;margin-bottom:12px;">⚠️</div>
        <div style="color:#fff;font-size:15px;font-weight:600;margin-bottom:8px;">Error: ${esc(e.message)}</div>
        <div style="color:#9996b0;font-size:13px;line-height:1.7;">
          Make sure your Gemini API key is correct.<br/>
          Get a free key at <strong>aistudio.google.com</strong>
        </div>
      </div>`;
    document.getElementById('resultsCount').textContent = 'Error';
  }

  document.getElementById('searchBtn').classList.remove('loading');
}

function renderResults(tools) {
  const grid = document.getElementById('resultsGrid');
  document.getElementById('resultsCount').textContent = tools.length + ' tools found';
  grid.innerHTML = '';

  tools.forEach((tool, i) => {
    const isSaved = savedTools.some(s => s.name === tool.name);
    const badgeClass = tool.pricing === 'free' ? 'badge-free' : tool.pricing === 'freemium' ? 'badge-freemium' : 'badge-paid';
    const card = document.createElement('div');
    card.className = 'tool-card';
    card.style.animationDelay = (i * 0.08) + 's';
    card.innerHTML = `
      <div class="card-top">
        <div class="card-name">${esc(tool.name)}</div>
        <span class="badge ${badgeClass}">${esc(tool.pricing)}</span>
      </div>
      <div class="tag-row">
        ${(tool.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}
        <span class="tag">${esc(tool.category)}</span>
      </div>
      <div class="card-desc">${esc(tool.description)}</div>
      <div class="card-match">✦ ${esc(tool.whyMatch)}</div>
      <div class="card-footer">
        <a class="card-link" href="${esc(tool.url)}" target="_blank" rel="noopener">Visit ${esc(tool.name)} →</a>
        <button class="card-save" onclick='toggleSave(this, ${JSON.stringify(JSON.stringify(tool))})'>${isSaved ? '♥ Saved' : '♡ Save'}</button>
      </div>`;
    grid.appendChild(card);
  });
}

function buildSkeletons(n) {
  let h = '<div style="display:contents">';
  for (let i = 0; i < n; i++) h += '<div class="skeleton-card"></div>';
  return h + '</div>';
}

function quickSearch(text) {
  document.getElementById('mainQuery').value = text;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  setTimeout(doSearch, 300);
}

function showResultsSection() {
  const s = document.getElementById('resultsSection');
  s.style.display = 'block';
  setTimeout(() => s.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
}

function clearResults() {
  document.getElementById('resultsSection').style.display = 'none';
  document.getElementById('mainQuery').value = '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function refineSearch() {
  document.getElementById('mainQuery').value = lastQuery + ' ';
  document.getElementById('mainQuery').focus();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSearch(); }
}

function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

function toggleSave(btn, toolJsonStr) {
  const tool = JSON.parse(toolJsonStr);
  const idx = savedTools.findIndex(s => s.name === tool.name);
  if (idx === -1) { savedTools.push(tool); btn.textContent = '♥ Saved'; }
  else { savedTools.splice(idx, 1); btn.textContent = '♡ Save'; }
  localStorage.setItem('tf_saved', JSON.stringify(savedTools));
}

function esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

window.addEventListener('scroll', () => {
  document.querySelector('.nav').style.boxShadow =
    window.scrollY > 10 ? '0 4px 30px rgba(0,0,0,0.4)' : 'none';
});
